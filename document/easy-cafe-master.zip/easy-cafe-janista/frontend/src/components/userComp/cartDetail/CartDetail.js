import React from "react";

const CartDetail = () => {
  return (
    <div className="box">
      {/* {state.order &&
        state.order.map((x, index) => (
          <div id="cards">
            <div className="BoxA"></div>
          </div>
        ))} */}
    </div>
  );
};

export default CartDetail;
